<?php

$host="localhost";
$user="root";
$pwd="";
$db="mukabuku";

$con = mysqli_connect($host,$user,$pwd,$db) or die (mysqli_connect_errno());


?>