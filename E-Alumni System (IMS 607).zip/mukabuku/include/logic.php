<?php

    // Don't display server errors 
    ini_set("display_errors", "off");

    // Initialize a database connection
    $conn = mysqli_connect("localhost", "root", "", "mukabuku");

    // Destroy if not possible to create a connection
    if(!$conn){
        echo "<h3 class='container bg-dark p-3 text-center text-warning rounded-lg mt-5'>Not able to establish Database Connection<h3>";
    }

    // Get data to display on index page
    $sql = "SELECT * FROM blog_data";
    $query = mysqli_query($conn, $sql);

    // Create a new post
    if(isset($_REQUEST['new_post'])){
        $title = $_REQUEST['title'];
        $content = $_REQUEST['content'];

        $sql = "INSERT INTO blog_data(title, content) VALUES('$title', '$content')";
        mysqli_query($conn, $sql);

        echo $sql;

        header("Location:index2.php?info=added");
        exit();
    }

    // Get post data based on id
    if(isset($_REQUEST['id'])){
        $id = $_REQUEST['id'];
        $sql = "SELECT * FROM blog_data WHERE id = $id";
        $query = mysqli_query($conn, $sql);
    }

    // Delete a post
    if(isset($_REQUEST['delete'])){
        $id = $_REQUEST['id'];

        $sql = "DELETE FROM blog_data WHERE id = $id";
        mysqli_query($conn, $sql);

        header("Location: index.php2");
        exit();
    }

    // Update a post
    if(isset($_REQUEST['update'])){
        $id = $_REQUEST['id'];
        $title = $_REQUEST['title'];
        $content = $_REQUEST['content'];

        $sql = "UPDATE blog_data SET title = '$title', content = '$content' WHERE id = $id";
        mysqli_query($conn, $sql);

        header("Location: index2.php");
        exit();
    }



include "include/index2.php"; // Include the database connection file

if (isset($_POST["new_post"])) {
    // Retrieve form data
    $title = $_POST['title'];
    $content = $_POST['content'];

    // Validate the data (you can add more validation as needed)
    if (empty($title) || empty($content)) {
        echo '<div class="alert alert-danger">Please fill in all the required fields.</div>';
    } else {
        // Insert the post data into the database
        $sql = "INSERT INTO posts (title, content) VALUES ('$title', '$content')";
        if (mysqli_query($con, $sql)) {
            echo '<div class="alert alert-success">Post created successfully!</div>';
        } else {
            echo '<div class="alert alert-danger">Error: ' . mysqli_error($con) . '</div>';
        }
    }
}


?>
