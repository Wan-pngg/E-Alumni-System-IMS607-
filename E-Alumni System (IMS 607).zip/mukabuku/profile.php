<?php
session_start();

//masukkan semua include yang penting disini terutama connection kepada database
include "include/db.php";
include "include/setting.php";
include "include/clean.php";
include "include/main_function.php";
include "include/security.php";


//kemaskini profile
if (isset($_POST["password"]))
{
	//encrypt pwd
$pwd_new=md5($_POST["password"]);
$name_edit=cucidata($_POST["name"]);
$email_edit=cucidata($_POST["email"]);

mysqli_query ($con, 
"UPDATE tbl_user set name='$name_edit',
email='$email_edit',pwd='$pwd_new' 
where userid='$_SESSION[userid]'") or die (mysqli_error($con));

$status=1;
	
	
}

//include pengguna

include "include/dataPengguna.php";

//KIRA PERCENTAGE ANDA BERKAWAN


//STEP 1:DAPATKAN BILANGAN SEMUA PENGGUNA
$TuSER=mysqli_query($con, "SELECT * FROM tbl_user where userid <> '$_SESSION[userid]' and status <> 1") or die (mysqli_error($con));
$ttlUser=mysqli_num_rows($TuSER);

//STEP 2: DAPATKAN BILANGAN KAWAN ANDA
$TKawan=mysqli_query($con, "SELECT * FROM tbl_friends where userid_1 = '$_SESSION[userid]'") or die (mysqli_error($con));
$ttlFr=mysqli_num_rows($TKawan);

//STEP 3: KIRA PERCENTAGE
if ($ttlFr==0)
{
$jumlahA=0;
$jumlahB=0;	
}
else
{
$jumlahA=number_format(($ttlFr/$ttlUser)*100,0);
$jumlahB=100-$jumlahA;
}






?>



<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Dashboard">
    <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">

     <title><?php echo $web_title; ?></title>

    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <!--external css-->
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
        
    <!-- Custom styles for this template -->
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/style-responsive.css" rel="stylesheet">
    

    <script src="assets/js/chart-master/Chart.js"></script>

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>

  <section id="container" >
      <!-- **********************************************************************************************************************************************************
      TOP BAR CONTENT & NOTIFICATIONS
      *********************************************************************************************************************************************************** -->
      <!--header start-->
      <header class="header black-bg">
              <div class="sidebar-toggle-box">
                  <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
              </div>
            <!--logo start-->
            <a href="index2.php" class="logo"><b> <?php echo $web_title2; ?></b></a>
            
                   
                   
                    <!-- inbox dropdown end -->
                </ul>
                <!--  notification end -->
            </div>
            <div class="top-menu">
            	<ul class="nav pull-right top-menu">
                    <li><a class="logout" href="logout.php">Logout</a></li>
            	</ul>
            </div>
        </header>
      <!--header end-->
      
      <!-- **********************************************************************************************************************************************************
      MAIN SIDEBAR MENU
      *********************************************************************************************************************************************************** -->
      <!--sidebar start-->
      <aside>
          <div id="sidebar"  class="nav-collapse ">
              <!-- sidebar menu start-->
              <ul class="sidebar-menu" id="nav-accordion">
              
              	  <p class="centered"><a href="profile.php">
<?php echo     '<img src="data:'.$showDataSQL["pictype"].';base64,'.base64_encode($showDataSQL["picture"]) .'" class="img-circle" width="120"></a>';
                  
                ?>
	
                  
                  
                  </p>
              	  <h5 class="centered"><?php echo $showDataSQL['username']; ?></h5>
              	  	
                 <!-- Menu Sistem -->
                
                
                
                
                
 
 <?php
 include ("include/menu.php");
 ?>
                
                
                
                
                
                
                
                
                

              </ul>
              <!-- sidebar menu end-->
          </div>
      </aside>
      <!--sidebar end-->
      
      <!-- **********************************************************************************************************************************************************
      MAIN CONTENT
      *********************************************************************************************************************************************************** -->
      <!--main content start-->
      <section id="main-content">
          <section class="wrapper site-min-height">
          	<h3><i class="fa fa-angle-right"></i> Welcome [<?php echo $showDataSQL['username']; ?>]</h3>
          	<div class="row mt">
          		<div class="col-lg-12">
          		
                <!-- ############# KOTA PERTAMA MULA ################################### -->
                <div class="col-md-4 mb">
							<!-- WHITE PANEL - TOP USER -->
							<div class="white-panel pn">
								<div class="white-header">
									<h5>USER PROFILE</h5>
								</div>
								<p>
                                
                                <?php echo     '<img src="data:'.$showDataSQL["pictype"].';base64,'.base64_encode($showDataSQL["picture"]) .'" class="img-circle" width="80"></a>';
                  
                ?>
                                
                 
                 
                  
                  
                              
                                
                                </p>
								<p><b><?php echo $showDataSQL["username"]; ?></b></p>
								<div class="row">
									<div class="col-md-6">
										<p class="small mt">MEMBER ID</p>
										<p>MB-<?php echo $showDataSQL["userid"]; ?></p>
									</div>
									<div class="col-md-6">
										<p class="small mt">EMAIL</p>
										<p><?php echo $showDataSQL["email"]; ?></p>
									</div>
								</div>
							</div>
						</div><!-- /col-md-4 -->
                
                 <!-- ############# KOTA PERTAMA TAMAT ################################### -->
                
        
                
                <!-- ############# KOTA KETIGA MULA ################################### -->
                <div class="col-lg-4 col-md-4 col-sm-4 mb">
							<div class="content-panel pn">
                            
                            
                            
                            
                            
								<div style="background-image: url(<?php echo 'data:'.$showDataSQL["pictype"].';base64,'.base64_encode($showDataSQL["picture"]).'"'; ?>)" id="spotify">
									<div class="col-xs-4 col-xs-offset-8">
										<button class="btn btn-sm btn-clear-g">ADD FRIEND</button>
									</div>
									<div class="sp-title">
										<h3><?php echo $showDataSQL["username"]; ?></h3>
									</div>
									
								</div>
								
							</div>
						</div><! --/col-md-4-->
                
                
                 <!-- ############# KOTA KETIGA TAMAT ################################### -->
                
                
                
                
                
                
          		</div>
          	</div>
			
            
            
            
            <div class="row mt">
          		<div class="col-lg-12">
                  <div class="form-panel">
                  	  <h4 class="mb"><i class="fa fa-angle-right"></i> User Profile</h4>
                     
                     <?php
					 if (isset($status)){echo "Successfully Updated your data!";}
					 ?>
                     
                     
                     
                     
                      <form class="form-horizontal style-form" method="post" name="update">
                        
                          
                           <div class="form-group">
                              <label class="col-lg-2 col-sm-2 control-label">Username</label>
                              <div class="col-lg-10">
                                  <p class="form-control-static"><?php echo $showDataSQL["username"]; ?></p>
                              </div>
                          </div>
                          
                          
                          
                          <div class="form-group">
                              <label class="col-sm-2 col-sm-2 control-label">Password</label>
                              <div class="col-sm-10">
                                  <input type="password"  name="password" value="<?php echo $showDataSQL["username"]; ?>" class="form-control" placeholder="">
                              </div>
                          </div>
                          
                          
                          
                          
                          <div class="form-group">
                              <label class="col-sm-2 col-sm-2 control-label">Name</label>
                              <div class="col-sm-10">
                                  <input type="text"  name="name" value="<?php echo $showDataSQL["name"]; ?>" class="form-control" placeholder="Name" required autocomplete="off">
                              </div>
                          </div>
                         
                         
                         
                         <div class="form-group">
                              <label class="col-sm-2 col-sm-2 control-label">Email</label>
                              <div class="col-sm-10">
                                  <input type="text"  name="email" value="<?php echo $showDataSQL["email"]; ?>" class="form-control" placeholder="Email" required autocomplete="off">
                              </div>
                          </div>
                         
						  
						  
						  <div class="form-group">
                              <label class="col-sm-2 col-sm-2 control-label">Phone Number</label>
                              <div class="col-sm-10">
                                  <input type="text"  name="hp" value="<?php echo $showDataSQL["hp"]; ?>" class="form-control" placeholder="Phone Number" required autocomplete="off">
                              </div>
                          </div>
						  
						  
                         <br>
                          <button type="submit" class="btn btn-theme btn-block">Update</button>
                         
                         
                      </form>
                  </div>
          		</div><!-- col-lg-12-->      	
          	</div><!-- /row -->
            
            
            
            
            
            
		</section><! --/wrapper -->
      </section><!-- /MAIN CONTENT -->

      <!--main content end-->
      <!--footer start-->
      <footer class="site-footer">
          <div class="text-center">
              <?php echo $copyright; ?>
              <a href="#" class="go-top">
                  <i class="fa fa-angle-up"></i>
              </a>
          </div>
      </footer>
      <!--footer end-->
  </section>

    <!-- js placed at the end of the document so the pages load faster -->
    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/jquery-ui-1.9.2.custom.min.js"></script>
    <script src="assets/js/jquery.ui.touch-punch.min.js"></script>
    <script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
    <script src="assets/js/jquery.scrollTo.min.js"></script>
    <script src="assets/js/jquery.nicescroll.js" type="text/javascript"></script>


    <!--common script for all pages-->
    <script src="assets/js/common-scripts.js"></script>

    <!--script for this page-->
    <script src="assets/js/sparkline-chart.js"></script>
  <script>
      //custom select box

      $(function(){
          $('select.styled').customSelect();
      });

  </script>


 <script src="assets/js/jquery.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>

    <!--BACKSTRETCH-->
    <!-- You can use an image of whatever size. This script will stretch to fit in any screen size.-->
    <script type="text/javascript" src="assets/js/jquery.backstretch.min.js"></script>
    <script>
        $.backstretch("assets/img/wawa.jpg", {speed: 500});
    </script>

  </body>
</html>
