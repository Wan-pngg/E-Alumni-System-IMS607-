<?php
session_start();

include "include/db.php";
include "include/setting.php";
include "include/clean.php";
include "include/security.php";
include "include/dataPengguna.php";
include "include/logic.php";
include "include/mukabuku";
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Dashboard">
    <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">

     <title><?php echo $web_title; ?></title>

    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <!--external css-->
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
        
    <!-- Custom styles for this template -->
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/style-responsive.css" rel="stylesheet">

   
  </head>
	<link rel="icon" href="./images/favicon.png" type="image/png" sizes="16x16">
<title>forum</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	<script src="main.js"></script>
	

</div>

</body>

  
  <body>

  <section id="container" >
      
      <!--header start-->
      <header class="header black-bg">
              <div class="sidebar-toggle-box">
                  <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
              </div>
            <!--logo start-->
            <a href="index2.php" class="logo"><b> <?php echo $web_title2; ?></b></a>
            <!--logo end-->
            <div class="nav notify-row" id="top_menu">
                <!--  notification start -->
                <ul class="nav top-menu">

                </ul>
                <!--  notification end -->
            </div>
            <div class="top-menu">
            	<ul class="nav pull-right top-menu">
                    <li><a class="logout" href="logout.php">Logout</a></li>
            	</ul>
            </div>
        </header>
      <!--header end-->
      
      <!--sidebar start-->
      <aside>
          <div id="sidebar"  class="nav-collapse ">
              <!-- sidebar menu start-->
              <ul class="sidebar-menu" id="nav-accordion">
              
              	  <p class="centered"><a href="profile.php">
<?php 

if ($_SESSION["type"]=="GROUP")
 {
	
echo     '<img src="data:'.$showDataSQL["phototype"].';base64,'.base64_encode($showDataSQL["group_photo"]) .'" class="img-circle" width="120"></a>';	
	
}
else
{
	
	
echo     '<img src="data:'.$showDataSQL["pictype"].';base64,'.base64_encode($showDataSQL["picture"]) .'" class="img-circle" width="120"></a>';	
	
	
}
					  				  					 					  
					  
?>
	
                  
                  
                  </p>
              	  <h5 class="centered">
					  
					  <?php 
					  
					  if ($_SESSION["type"]=="GROUP")
 						{
						  echo $showDataSQL['group_username']; 
					  }
					  else
					  {  
						echo $showDataSQL['username']; 
					  }
					  ?></h5> 
					  
              	  	
                 <!-- Menu Sistem -->
                
                
                
                
                
 
 <?php
 include ("include/menu.php");
 ?>
                
                
                
                
                
                
                
                
                

              </ul>
              <!-- sidebar menu end-->
          </div>
      </aside>
      <!--sidebar end-->
      

    
<section id="main-content">
          <section class="wrapper site-min-height">
          	<h3><i class="fa fa-angle-right"></i> Welcome to Faqs [<?php if ($_SESSION["type"]=="GROUP")
 						{
						  echo $showDataSQL['group_username']; 
					  }
					  else
					  {  
						echo $showDataSQL['username']; 
					  } ?>]</h3>
          	<div class="row mt">
          		<div class="col-lg-12">
          		
					<h1 title>FAQs</title></h1>
   <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            color: white; /* Set text color to white */
            font-size: 18px; /* Set font size to 18px */
        }

        h2 {
            border-bottom: 1px solid #ccc;
            padding-bottom: 10px;
            margin-bottom: 20px;
            color: white; /* Set heading color to white */
            font-size: 24px; /* Set heading font size to 24px */
        }

        .question {
            font-weight: bold;
            cursor: pointer;
        }

        .answer {
            display: none;
        }
    </style>

					
					
					<div class="container mt-5">
<body>
    <h2>Frequently Asked Questions</h2>

    <div class="faq">
        <div class="question">Q: What is E-Alumni?</div>
        <div class="answer">A: E-Alumni is a website that make an ex-student communicate with each other .</div>
    </div>

    <div class="faq">
        <div class="question">Q: How do I use this website?</div>
        <div class="answer">A: Just browse to the website and explore the different sections.</div>
    </div>

    <div class="faq">
        <div class="question">Q: Can I download the content?</div>
        <div class="answer">A: Yes, you can download the content for personal use.</div>
    </div>

    <div class="faq">
        <div class="question">Q: Is this website free?</div>
        <div class="answer">A: Yes, this website is completely free to use.</div>
    </div>
	<div class="faq">
        <div class="question">Q: What is the contact number of the Admin?</div>
        <div class="answer">A: The contact number if the admin for this website is 0132726667.</div>
    </div>
	<div class="faq">
        <div class="question">Q: Who make this website?</div>
        <div class="answer">A: the one who make this website is a student of UITM Machang.</div>
    </div>
	</body>
						
	


    <!-- js placed at the end of the document so the pages load faster -->
    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/jquery-ui-1.9.2.custom.min.js"></script>
    <script src="assets/js/jquery.ui.touch-punch.min.js"></script>
    <script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
    <script src="assets/js/jquery.scrollTo.min.js"></script>
    <script src="assets/js/jquery.nicescroll.js" type="text/javascript"></script>


    <!--common script for all pages-->
    <script src="assets/js/common-scripts.js"></script>

    <!--script for this page-->
    
  <script>
      //custom select box

      $(function(){
          $('select.styled').customSelect();
      });

	  </script>
	  
	  <script type="text/javascript" src="assets/js/jquery.backstretch.min.js"></script>
    <script>
        $.backstretch("assets/img/sasa.jpg", {speed: 500});
    </script>
	  
	    <script>
        const questions = document.querySelectorAll(".question");
        questions.forEach(question => {
            question.addEventListener("click", () => {
                const answer = question.nextElementSibling;
                answer.style.display = answer.style.display === "block" ? "none" : "block";
            });
        });
    </script>
	  
	  
  </script>
			
					
  </body>

</html>
