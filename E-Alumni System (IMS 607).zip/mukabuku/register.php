<?php
session_start();

include "include/db.php";
include "include/setting.php";
include "include/clean.php";
include "include/main_function.php";

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Dashboard">
    <meta name="keyword" content="<?php echo $keywords; ?>">

    <title><?php echo $web_title; ?></title>

    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <!--external css-->
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
        
    <!-- Custom styles for this template -->
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/style-responsive.css" rel="stylesheet">


  </head>

  <body>
      <!-- **********************************************************************************************************************************************************
      MAIN CONTENT
      *********************************************************************************************************************************************************** -->

	  <div id="login-page">
	  	<div class="container">
	  	
        
        
      
		      <form class="form-login" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" enctype="multipart/form-data">
		        
               
                
                
                <h2 class="form-login-heading">New User Account</h2>
		        <div class="login-wrap">
		            
                    <?php
		
		if (!isset($_POST["username"]))
		{
		?> 
              
                    <label class="checkbox">
		                <span class="pull-left">
		                  Username <font color="red">*</font>
		
		                </span>
		            </label>
                    
                    
                    <input type="text" class="form-control" placeholder="Username" autofocus name="username" autocomplete="off" required>
		            <br>
                    
                    
                    <label class="checkbox">
		                <span class="pull-left">
		                  Password <font color="red">*</font>
		
		                </span>
		            </label>
                    
		            <input type="password" class="form-control" placeholder="Password" name="password1" autocomplete="off" required autocomplete="off">
		           <br>
                   
    
                  <label class="checkbox">
		                <span class="pull-left">
		                 Confirm Password <font color="red">*</font>
		
		                </span>
		            </label>
                    
		            <input type="password" class="form-control" placeholder="Confirm Password" name="password2" autocomplete="off" required autocomplete="off">
		           <br>
                   
 
                  <label class="checkbox">
		                <span class="pull-left">
		                  Name <font color="red">*</font>
		
		                </span>
		            </label>
                    
                    
                    <input type="text" class="form-control" placeholder="Name" name="name" autocomplete="off" required autocomplete="off">
		            <br>
                   
                   
                  <label class="checkbox">
		                <span class="pull-left">
		                  Email Address <font color="red">*</font>
		
		                </span>
		            </label>
                    
                    
                  <input type="email" class="form-control" placeholder="Email Address" name="email" autocomplete="off" required autocomplete="off">
		            <br>
                   
                  <label class="checkbox">
		                <span class="pull-left">
		                  Phone Number <font color="red">*</font>
		
		                </span>
	              </label>
                  <input type="Text" class="form-control" placeholder="Phone Number" name="hp" autocomplete="off" required autocomplete="off">
		           <br>
	              <label class="checkbox">
		                <span class="pull-left">
		                  Photo <font color="red">*</font>
		
		                </span>
		            </label>
					

		           <input type="file" class="form-control" name="photo" required autocomplete="off" accept="image/jpeg,image/x-png">
		           <br>
   
                   
	              <button class="btn btn-theme btn-block" type="submit"><i class="fa fa-lock"></i> REGISTER</button>
		            <hr>
		            
					
					
		         
	              <div class="registration">
		                Do you have an account with us?<br/>
		                <a class="" href="index.php">
		                    Click here to login
		                </a>
		            </div>
		
            <?php
		}
		else
		{
		?>
        
        	<?php
							 daftar(cucidata($_POST["username"]),cucidata($_POST["password1"]),cucidata($_POST["password2"]),cucidata($_POST["name"])
							 ,cucidata($_POST["email"]),$_FILES["photo"]["name"],$con,$_FILES["photo"]["tmp_name"], $_POST["hp"]);
							 
		}
                        ?> 
        
        
        
		        </div>
		
		          	
		      </form>	 
              
	  	
	  	</div>
	  </div>

    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>

    <!-- You can use an image of whatever size. This script will stretch to fit in any screen size.-->
    <script type="text/javascript" src="assets/js/jquery.backstretch.min.js"></script>
    <script>
        $.backstretch("assets/img/wawa.jpg", {speed: 500});
    </script>


	  
	  
  </body>
</html>
