<?php
session_start();

//masukkan semua include yang penting disini terutama connection kepada database
include "include/db.php";
include "include/setting.php";
include "include/clean.php";
include "include/main_function.php";
include "include/security.php";
include "include/dataPengguna.php";


?>



<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Dashboard">
    <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">

     <title><?php echo $web_title; ?></title>

    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <!--external css-->
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
        
    <!-- Custom styles for this template -->
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/style-responsive.css" rel="stylesheet">

  </head>

  <body>

  <section id="container" >
      <!-- **********************************************************************************************************************************************************
      TOP BAR CONTENT & NOTIFICATIONS
      *********************************************************************************************************************************************************** -->
      <!--header start-->
      <header class="header black-bg">
              <div class="sidebar-toggle-box">
                  <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
              </div>
            <!--logo start-->
            <a href="index2.php" class="logo"><b> <?php echo $web_title2; ?></b></a>
            <!--logo end-->
            <div class="nav notify-row" id="top_menu">
                <!--  notification start -->
                <ul class="nav top-menu">
                    <!-- settings start -->
                  
                    <!-- settings end -->
                    <!-- inbox dropdown start-->
                   
           
                    <!-- inbox dropdown end -->
                </ul>
                <!--  notification end -->
            </div>
            <div class="top-menu">
            	<ul class="nav pull-right top-menu">
                    <li><a class="logout" href="logout.php">Logout</a></li>
            	</ul>
            </div>
        </header>
      <!--header end-->
      
      <!-- **********************************************************************************************************************************************************
      MAIN SIDEBAR MENU
      *********************************************************************************************************************************************************** -->
      <!--sidebar start-->
      <aside>
          <div id="sidebar"  class="nav-collapse ">
              <!-- sidebar menu start-->
              <ul class="sidebar-menu" id="nav-accordion">
              
              	  <p class="centered"><a href="profile.php">
<?php 

if ($_SESSION["type"]=="GROUP")
 {
	
echo     '<img src="data:'.$showDataSQL["phototype"].';base64,'.base64_encode($showDataSQL["group_photo"]) .'" class="img-circle" width="120"></a>';	
	
}
else
{
	
	
echo     '<img src="data:'.$showDataSQL["pictype"].';base64,'.base64_encode($showDataSQL["picture"]) .'" class="img-circle" width="120"></a>';	
	
	
}
					  				  					 					  
					  
?>
	
                  
                  
                  </p>
              	  <h5 class="centered">
					  
					  <?php 
					  
					  if ($_SESSION["type"]=="GROUP")
 						{
						  echo $showDataSQL['group_username']; 
					  }
					  else
					  {  
						echo $showDataSQL['username']; 
					  }
					  ?></h5> 
					  
              	  	
                 <!-- Menu Sistem -->
                
                
                
                
                
 
 <?php
 include ("include/menu.php");
 ?>
                
                
                
                
                
                
                
                
                

              </ul>
              <!-- sidebar menu end-->
          </div>
      </aside>
      <!--sidebar end-->
      
      <!-- **********************************************************************************************************************************************************
      MAIN CONTENT
      *********************************************************************************************************************************************************** -->
      <!--main content start-->
      <section id="main-content">
          <section class="wrapper site-min-height">
          	<h3><i class="fa fa-angle-right"></i> Welcome [<?php if ($_SESSION["type"]=="GROUP")
 						{
						  echo $showDataSQL['group_username']; 
					  }
					  else
					  {  
						echo $showDataSQL['username']; 
					  } ?>]</h3>
          	<div class="row mt">
          		<div class="col-lg-12">
          		
                
              
              
              <! -- KOTAK kedua 1 column MULA XXXXXXXXXXXXXXXXXXXXXXXXXXXX -->
      
						<!-- INLINE FORM ELELEMNTS -->
          	<div class="row mt">
          		<div class="col-lg-12">
          			<div class="form-panel">
                  	  <h4 class="mb"><i class="fa fa-angle-right"></i> Add New Document</h4>
						
						
						<?php
						
						if (isset ($_POST["submit"]))
							
						{
							
						tambahDocs2($_FILES["document"]["name"],$_FILES["document"]["tmp_name"],$con);	
							
							
						}
						
							 
                        ?> 
						
						
						
						
                      <form class="form-inline" role="form" method="post" enctype="multipart/form-data">
                          <div class="form-group">
                              <label class="sr-only" for="exampleInputEmail2">Multiple Upload </label>
                              <input type="file" name="document[]" class="form-control" id="exampleInputEmail2" placeholder="Select Document" multiple required>
                          </div>
                          
                          <button type="submit" name="submit" class="btn btn-theme">Submit</button>
                      </form>
						
						
						<?php
						
						$dataDocs=mysqli_query($con,"SELECT * FROM tbl_document");
						$bil_docs=mysqli_num_rows ($dataDocs);
						
						while ($showDocs=mysqli_fetch_array($dataDocs))
						{
							
							echo "$showDocs[doc_name] <a href='upload/$showDocs[unik]' target='_blank'> Download </a> <br>";
							
						}
						
						
						?>
						
						
						
          			</div><!-- /form-panel -->
          		</div><!-- /col-lg-12 -->
          	</div><!-- /row -->
						
						</div>
      				</div><!--/showback -->
                
                </div>
                
                
                 <! -- KOTAK kedua 1 column TAMAT XXXXXXXXXXXXXXXXXXXXXXXXXXXX -->
                
                
                
                
                
          		</div>
          	</div>
			
		</section><! --/wrapper -->
      </section><!-- /MAIN CONTENT -->

      <!--main content end-->
      <!--footer start-->
      <footer class="site-footer">
          <div class="text-center">
              <?php echo $copyright; ?>
              <a href="#" class="go-top">
                  <i class="fa fa-angle-up"></i>
              </a>
          </div>
      </footer>
      <!--footer end-->
  </section>

    <!-- js placed at the end of the document so the pages load faster -->
    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/jquery-ui-1.9.2.custom.min.js"></script>
    <script src="assets/js/jquery.ui.touch-punch.min.js"></script>
    <script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
    <script src="assets/js/jquery.scrollTo.min.js"></script>
    <script src="assets/js/jquery.nicescroll.js" type="text/javascript"></script>


    <!--common script for all pages-->
    <script src="assets/js/common-scripts.js"></script>

    <!--script for this page-->
    
  <script>
      //custom select box

      $(function(){
          $('select.styled').customSelect();
      });

  </script>


	  
	  <script type="text/javascript" src="assets/js/jquery.backstretch.min.js"></script>
    <script>
        $.backstretch("assets/img/wawa.jpg", {speed: 500});
    </script>

  </body>
</html>
